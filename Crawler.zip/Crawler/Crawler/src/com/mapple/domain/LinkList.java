package com.mapple.domain;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class LinkList
{
	private static List<String> urlList = new LinkedList<String>();
	private static Map<String, Integer> urlMap = new HashMap<String, Integer>();
	public synchronized static Integer getSize()
	{
		return urlList.size();
	}
	public synchronized static String getUrl()
	{
		if(urlList.size()>0)
		{
			String url =  urlList.get(0);
			urlList.remove(0);
			return url;
		}
		else
		{
			return null;
		}
	}
	public synchronized static void addUrl(String url)
	{
		if(!urlMap.containsKey(url))
		{
			if(urlList.size()<1000000)
			{
				System.out.println(url);
				urlMap.put(url, 0);
				urlList.add(url);
			}
		}
		
		
	}
}
