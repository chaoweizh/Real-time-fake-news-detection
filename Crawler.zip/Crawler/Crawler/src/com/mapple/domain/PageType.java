package com.mapple.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PageType
{
	public static String indexPage="http://us.cnn.com/index.html";
	
	public static String tagPage = "http://us.cnn.com/[a-zA-Z]+";
	
	public static String contentPage = "http://us.cnn.com/[0-9]*/[0-9]*/[0-9]*/[a-zA-Z0-9]*/[a-zA-Z0-9-]*/index.html";
	
	
	public static Integer checkType(String url)
	{
		Pattern pattern = Pattern.compile(indexPage);
		Matcher matcher = pattern.matcher(url);
		
		while (matcher.find())
		{
			return 0;
			
		}
		
		pattern = Pattern.compile(tagPage);
		matcher = pattern.matcher(url);
		
		while (matcher.find())
		{
			return 1;
			
		}
		
		pattern = Pattern.compile(contentPage);
		matcher = pattern.matcher(url);
		
		while (matcher.find())
		{
			return 2;
			
		}
		return -1;
	}
	public static void main(String[] args)
	{
		Pattern pattern = Pattern.compile(contentPage);
		Matcher matcher = pattern.matcher("http://us.cnn.com/2017/05/08/travel/the-world-luxury-ship-one-square-meter/index.html");
		
		while (matcher.find())
		{
			System.out.println(matcher.group(0));
			
		}
	}
}
