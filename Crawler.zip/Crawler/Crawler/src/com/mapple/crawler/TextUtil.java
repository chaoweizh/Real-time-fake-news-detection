package com.mapple.crawler;

import java.io.UnsupportedEncodingException;

import javax.swing.text.html.parser.ParserDelegator;

import org.htmlparser.Node;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.AndFilter;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.filters.TagNameFilter;
import org.htmlparser.tags.TableTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class TextUtil
{
	public static String getTitle(String html)
	{
//		String temp = html.substring(
//				html.indexOf("<h1 class=\"pg-headline\">") + 24, html.length());
//		String title = temp.substring(0, temp.indexOf("</h1>")).replaceAll(
//				"</?[^>]+>", "");
		String title = "";
		try
		{
			Parser parser = new Parser(html);
			NodeFilter filter_text = new AndFilter(new TagNameFilter("h1"),new HasAttributeFilter("class","pg-headline"));
			 NodeList nodelist2 = parser.parse(filter_text);
	            Node[] nodes = nodelist2.toNodeArray();
	            StringBuffer buftext = new StringBuffer();  
	            String line = null;  
	            for(int i=0; i<nodes.length; i++){
	                line = nodes[i].toPlainTextString();  
	                 if(line != null){  
	                     buftext.append(line);  
	                 }  
	            }  
	            title = buftext.toString();  
	           
		} catch (ParserException e)
		{
	
			e.printStackTrace();
		}
		

		return title;

	}

	public static String getAuthor(String html)
	{
//		String temp = html.substring(
//				html.indexOf("<span class=\"metadata__byline__author\">") + 39,
//				html.length());
//		String author = temp.substring(0, temp.indexOf("</span>")).replaceAll(
//				"</?[^>]+>", "");
		String author = "";
		try
		{
			Parser parser = new Parser(html);
			NodeFilter filter_text = new AndFilter(new TagNameFilter("span"),new HasAttributeFilter("class","metadata__byline__author"));
			 NodeList nodelist2 = parser.parse(filter_text);
	            Node[] nodes = nodelist2.toNodeArray();
	            StringBuffer buftext = new StringBuffer();  
	            String line = null;  
	            for(int i=0; i<nodes.length; i++){
	                line = nodes[i].toPlainTextString();  
	                 if(line != null){  
	                     buftext.append(line);  
	                 }  
	            }  
	            author = buftext.toString();  
	           
		} catch (ParserException e)
		{
	
			e.printStackTrace();
		}

		return author;
	}

	public static String getTime(String html)
	{
//		String temp = html.substring(
//				html.indexOf("<p class=\"update-time\">") + 23, html.length());
//		String time = temp.substring(0, temp.indexOf("</p>")).replaceAll(
//				"</?[^>]+>", "");
		String time = "";
		try
		{
			Parser parser = new Parser(html);
			NodeFilter filter_text = new AndFilter(new TagNameFilter("p"),new HasAttributeFilter("class","update-time"));
			 NodeList nodelist2 = parser.parse(filter_text);
	            Node[] nodes = nodelist2.toNodeArray();
	            StringBuffer buftext = new StringBuffer();  
	            String line = null;  
	            for(int i=0; i<nodes.length; i++){
	                line = nodes[i].toPlainTextString();  
	                 if(line != null){  
	                     buftext.append(line);  
	                 }  
	            }  
	            time = buftext.toString();  
	           
		} catch (ParserException e)
		{
	
			e.printStackTrace();
		}
		return time;

	}

	public static String getContent(String html) 
	{
		String temp = html.substring(
				html.indexOf("<div class=\"zn-body__paragraph\">") + 32,
				html.length());
		String content = "";
		try
		{
			Parser parser = new Parser(html);
			NodeFilter filter_text = new AndFilter(new TagNameFilter("div"),new HasAttributeFilter("class","zn-body__paragraph"));
			 NodeList nodelist2 = parser.parse(filter_text);//���˳�����filter_text�Ľڵ�LIST  
	            Node[] nodes = nodelist2.toNodeArray();//ת��Ϊ����  
	            StringBuffer buftext = new StringBuffer();  
	            String line = null;  
	            for(int i=0; i<nodes.length; i++){//ѭ���ӵ�buftext��  
	                line = nodes[i].toPlainTextString();  
	                 if(line != null){  
	                     buftext.append(line);  
	                 }  
	            }  
	            content = buftext.toString();  
	           
		} catch (ParserException e)
		{
		
			e.printStackTrace();
		}
		 
		//ParserDelegator delegator = new ParserDelegator();
//		StringBuffer text = new StringBuffer();
//		Parser parser = Parser.createParser(
//				new String(temp.getBytes(), "UTF-8"), "UTF-8");
//		// �������еĽڵ�
//
//		NodeList nodes = parser.extractAllNodesThatMatch(new NodeFilter()
//		{
//			public boolean accept(Node node)
//			{
//				return true;
//			}
//		});
//		System.out.println(nodes.size()); 
//		for (int i = 0; i < nodes.size(); i++)
//		{
//			Node nodet = nodes.elementAt(i);
//			// System.out.println(nodet.getText());
//			text.append(new String(nodet.toPlainTextString().getBytes("UTF-8"))
//					+ "/r/n");
//		}
//		String content = text.toString().replaceAll("</?[^>]+>", "").trim();
//		String content = temp
//				.substring(
//						0,
//						temp.indexOf("<div class=\"zn-body__read-more-outbrain\">"))
//				.replaceAll("</?[^>]+>", "").trim();
		return content;
	}

//	public static void main(String[] args)
//	{
//		String html = GetStringFromUrl
//				.getStringFromUrl("http://us.cnn.com/2017/05/08/travel/the-world-luxury-ship-one-square-meter/index.html");
//		System.out.println(getTitle(html));
//		System.out.println(getAuthor(html));
//
//		System.out.println(getTime(html));
//
//		try
//		{
//			System.out.println(getContent(html));
//		} catch (Exception e)
//		{
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
}
