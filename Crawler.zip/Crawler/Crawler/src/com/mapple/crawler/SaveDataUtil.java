package com.mapple.crawler;



import java.io.File;
import java.io.FileOutputStream;

import net.sf.json.JSONObject;

import com.mapple.model.ContentData;

public class SaveDataUtil
{
	public static void save(ContentData data)
	{
		try
		{
		JSONObject json = JSONObject.fromObject(data);
		String str = json.toString();
		String name = data.getTitle();
		if(name.length()>50)
		{
			name= name.substring(0, 50);
		}
		System.out.println("����"+name+"...");
		File txt=new File("d:\\txt\\"+System.currentTimeMillis()+".txt");
        if(!txt.exists()){  
            txt.createNewFile();  
       }  
        byte bytes[]=new byte[64];   
        bytes=str.getBytes();  
        int b=bytes.length;   
        FileOutputStream fos=new FileOutputStream(txt); 
        fos.write(bytes,0,b); 
        fos.write(bytes);
        fos.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
