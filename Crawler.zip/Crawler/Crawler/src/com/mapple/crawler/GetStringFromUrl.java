package com.mapple.crawler;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
import java.util.zip.GZIPInputStream;



public class GetStringFromUrl
{
	
	private static String[] userAgents =
	{
			"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/6.0)",
			"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.154 Safari/537.36 LBBROWSER",
			"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/6.0)",
			"Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko LBBROWSER" };
	
	/**
	 * �������һ��useragent
	 * @return
	 */
	public static String getUserAgent()
	{
		Random random = new Random();
		return userAgents[random.nextInt(4)];
	}
	public static String getStringFromUrl(String urlStr)
	{
		if(urlStr.indexOf("http:")==-1)
		{
			urlStr = "http://"+urlStr;
		}
		URL url = null;
		HttpURLConnection conn = null;
		InputStream inputStream = null;
		FileOutputStream fos = null;
		try
		{
			
			url = new URL(urlStr);
			conn = (HttpURLConnection) url.openConnection();
			// ���ó�ʱ��Ϊ5��
			conn.setConnectTimeout(5 * 1000);
			conn.setReadTimeout(20 * 1000);
			// ��ֹ���γ���ץȡ������403����
			conn.setRequestProperty("User-Agent",
					getUserAgent());
			
			int state = conn.getResponseCode();
			if(state!=200)
			{
				return "";
			}
			String gzip = conn.getHeaderField("Content-Encoding");
			// �õ�������
			inputStream = conn.getInputStream();

			// ��ȡ�ֽ�����
			byte[] getData = null;
			if (gzip != null && "gzip".equals(gzip))
			{
				getData = decompress(readInputStream(inputStream));
			} else
			{
				getData = readInputStream(inputStream);
			}
			
			

			return new String(getData,"UTF-8");
		} catch (Exception e)
		{
			e.printStackTrace();
			return "";
		} finally
		{
			if (fos != null)
			{
				try
				{
					fos.close();
				} catch (IOException e)
				{
				}
			}
			if (inputStream != null)
			{
				try
				{
					inputStream.close();
				} catch (IOException e)
				{
				}
			}
			if (conn != null)
			{
				conn.disconnect();
			}
		}
	}
	/**
	 * ���������л�ȡ�ֽ�����
	 * 
	 * @param inputStream
	 * @return
	 * @throws IOException
	 */
	public static byte[] readInputStream(InputStream inputStream)
			throws IOException
	{
		byte[] buffer = new byte[1024];
		int len = 0;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while ((len = inputStream.read(buffer)) != -1)
		{
			bos.write(buffer, 0, len);
			//System.out.println(new String(buffer));
		}
		bos.close();
		return bos.toByteArray();
	}

	/**
	 * ���ݽ�ѹ��
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public static byte[] decompress(byte[] data) throws Exception
	{
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		// ��ѹ��

		decompress(bais, baos);

		data = baos.toByteArray();

		baos.flush();
		baos.close();

		bais.close();

		return data;
	}

	/**
	 * ���ݽ�ѹ��
	 * 
	 * @param is
	 * @param os
	 * @throws Exception
	 */
	public static void decompress(InputStream is, OutputStream os)
			throws Exception
	{

		GZIPInputStream gis = new GZIPInputStream(is);

		int count;
		byte data[] = new byte[1024];
		while ((count = gis.read(data, 0, 1024)) != -1)
		{
			os.write(data, 0, count);
		}

		gis.close();
	}
	
	
}