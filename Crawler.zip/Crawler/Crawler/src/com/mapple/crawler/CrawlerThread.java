package com.mapple.crawler;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.soap.Text;

import com.mapple.domain.LinkList;
import com.mapple.domain.PageType;
import com.mapple.model.ContentData;

public class CrawlerThread
{
	
	public static void main(String[] args)
	{
		craw();
	}
	
	public static void craw()
	{
		String startUrl = PageType.indexPage;
		String html = GetStringFromUrl.getStringFromUrl(startUrl);
		getUrls(html);
		while(LinkList.getSize()>0)
		{
			try
			{
				Thread.sleep(2000);
			} catch (InterruptedException e)
			{
				
				e.printStackTrace();
			}
			String url = LinkList.getUrl();
			System.out.println("======"+url);
			//url = "http://us.cnn.com/2017/05/08/travel/the-world-luxury-ship-one-square-meter/index.html";
			String content = GetStringFromUrl.getStringFromUrl(url);
			if(content==null||"".equals(content))
				continue;
			System.out.println(PageType.checkType(url));
			if(PageType.checkType(url)==2)
			{
				
				ContentData contentData = new ContentData();
				contentData.setTitle(TextUtil.getTitle(content));
				contentData.setAuthor(TextUtil.getAuthor(content));
				contentData.setTime(TextUtil.getTime(content));
				contentData.setContent(TextUtil.getContent(content));
				SaveDataUtil.save(contentData);
				
			}else
			{
				getUrls(content);
			}
		}

	}

	private static void getUrls(String html)
	{

		Pattern pattern = Pattern.compile( "<a[^>]*href=(\"([^\"]*)\"|\'([^\']*)\'|([^\\s>]*))[^>]*>(.*?)</a>");
		Matcher matcher = pattern.matcher(html);
		while (matcher.find())
		{
			String url = matcher.group(1).replace("\"", "");
			if(url.contains("http"))
				continue;
			//String temp = url.substring(url.indexOf("href=\"")+5, url.length());
			//temp = temp.substring(0,temp.indexOf("\""));
			url = "http://us.cnn.com"+url;
			System.out.println(url);
			if (PageType.checkType(url)!=-1)
			{
				
				LinkList.addUrl(url);
			}
		}

	}
}
